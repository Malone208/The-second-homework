# HW2-姜佳岩

任务一使用 SGLang 0.5.14、Ray 2.56.0、Qwen/Qwen3-0.6B。
用户已确认 Python 3.12.3、PyTorch 2.11.0、CUDA runtime 13.0、nvcc 13.0.88，GPU 为 RTX 4060 Laptop GPU。
2026-10-01 完成 run-1；64 条测量请求全部成功，原始事件与汇总已核对。
任务一及任务二技术内容已完成，report.pdf 为 6 页，其中任务二占第 4、5 页。
2026-10-03 已将本人提供的文字加入第 6 页：第（2）问来自 Word 原文，第（3）问保留 Word 原文，并在开头加入本人在聊天中提供的补充句。
第（1）问由 AI 根据会话记录整理。文字反馈、少量修改与概念解释等实际辅助记录在 AI 使用说明中。

## 服务环境

本实验复用了第一次挑战中已搭建的 Ubuntu-24.04 和 `~/venvs/sglang` 环境。
系统依赖包括 build-essential、python3.12-dev 和 CUDA Toolkit 13.0；nvcc 位于 `/usr/local/cuda-13.0/bin/`。
安装 Python 依赖使用 uv，关键命令为：

```bash
~/.local/bin/uv pip install --python ~/venvs/sglang/bin/python "sglang[all]==0.5.14" "ray==2.56.0"
```

本次实际 PyTorch 为 2.11.0、CUDA runtime 为 13.0（环境检查截图）；
SGLang、Ray、PyTorch 版本也记录在两组 `preparation.json` 中。
以上命令针对已有兼容环境；CUDA Toolkit 和显卡驱动的安装不由 uv 完成。

在 Windows PowerShell 中进入 Ubuntu：

```powershell
wsl -d Ubuntu-24.04
```

在 Ubuntu 中：

```bash
source ~/venvs/sglang/bin/activate
~/.local/bin/uv pip install --python ~/venvs/sglang/bin/python "ray==2.56.0"
export CUDA_HOME=/usr/local/cuda-13.0
export PATH="$CUDA_HOME/bin:$PATH"
SGLANG_USE_MODELSCOPE=true python -m sglang.launch_server \
  --model-path Qwen/Qwen3-0.6B --host 127.0.0.1 --port 30000 \
  --context-length 4096 --mem-fraction-static 0.6 --stream-interval 1
```

保留服务终端。在另一个 Ubuntu 终端中操作客户端，不要同时运行其他模型请求。

## 脚本与运行

`src/target1/experiment.py` 包含负载构造、原生流式接口检查和正式实验。
客户端并发使用标准库线程池，最大并发为 8；此脚本没有调用 Ray 的任务 API。
它直接发送 `input_ids`，不经过聊天模板，不把字符数当成 token 数。

```bash
source ~/venvs/sglang/bin/activate
cd ~/HW2-姜佳岩
python src/target1/experiment.py prepare
python src/target1/experiment.py probe
```

`prepare` 默认从本地 ModelScope 缓存寻找 Qwen3-0.6B 分词器，禁止联网下载。
如果没有唯一匹配，使用 `prepare --tokenizer /本地模型目录`。
两组各 32 条，每条 2112 token；共享组为 2048 token 前缀与 64 token 独立后缀。
成对输入只改变第一个 token，分散组的首 token 各不相同；每个后缀的首 token 也不同，避免超过 2048 token 的跨请求匹配。
负载随机种子为 2026。

`probe` 用 64 token 短请求检查 HTTP/SSE、累计输出 token、缓存字段和终止标记，结果不计入正式实验。
确认探测成功且首个输出事件只含一个 token 后，首次实验使用以下命令。本次提交已包含 `run-1` 的结果；重新运行请使用下方“重复实验”的命令。

```bash
python src/target1/experiment.py run --run-name run-1
```

服务短请求预热不计入测量。每组开始前调用 POST `/flush_cache`，必须返回 HTTP 200 与成功文本；等待清空成功后才发测量请求。
共享组额外发送一条独立的前缀预热请求，分散组不发送。
固定 sampling_params：temperature=0、max_new_tokens=16、ignore_eos=true、sampling_seed=2026。
两组均按 index 0..31 的顺序发送，最多同时存在 8 条客户端请求。
遇到失败保留原始结果，不静默重试或删除失败项。重复实验使用 run-2 等新目录。

### 重复实验

确认模型服务已启动，在另一个 Ubuntu 终端运行：

```bash
source ~/venvs/sglang/bin/activate
cd ~/HW2-姜佳岩
python src/target1/experiment.py run --run-name run-2
```

这里直接复用提交中的固定负载，不需要重新执行 `prepare` 或 `probe`。
`cd` 后的目录应为实际解压位置，其中应能找到 `src/target1/experiment.py`。
新结果分别保存到 `results/target1/shared_prefix/run-2/`、`results/target1/dispersed_prefix/run-2/`，两组对比汇总保存到 `results/target1/run-2-comparison.json`；`run-1` 的结果保留。
如果 `run-2` 已有结果，把命令中的名称改为 `run-3`，以后依次递增。已有结果时脚本会拒绝覆盖，这条提示不表示原实验失败。
报告及下方主表仍对应已完成的 `run-1`，重跑不会自动更新报告。

## 结果与指标

- `src/target1/workloads/`：固定负载、前缀预热输入及 SHA256。
- `results/target1/probe.json`：探测响应，排除于主表。
- `results/target1/{shared_prefix,dispersed_prefix}/run-1/preparation.json`：环境版本、清空缓存证明及预热响应，排除于主表。
- 同目录 `streams/request-00.json` 等：每个 SSE 事件的客户端时间及原始 JSON。
- 同目录 `requests.jsonl`：按请求顺序排列的逐请求指标。
- 同目录 `summary.json`：该组 32 条测量请求的汇总。
- `results/target1/run-1-comparison.json`：两组汇总与完成条件检查。

主表只从两组 summary.json 读取，预热和 probe 不参与统计。
成功率为成功测量请求数/32；成功还要求实际输入 2112 token、输出 16 token、收到 finish_reason 与 [DONE]。
缓存命中率为 sum(cached_tokens)/sum(prompt_tokens)。实际 Prefill token 按题目口径计算 sum(prompt_tokens-cached_tokens)。
吞吐量同时记录 requests/s 与输出 token/s；时间范围为首条测量请求开始发送至最后一条测量响应结束，不含预热。
TTFT 从发请求前至首个输出 token 事件到达客户端；TPOT=(最后输出 token 到达时间-首 token 到达时间)/(输出 token 数-1)；总延迟至流结束。
这些是客户端观测值，包含 HTTP/传输与客户端处理开销。若首个事件累计输出多于 1 token，检查失败，需处理流式粒度后再测，不能直接把它当精确首 token 时间。
p50/p95 使用排序后线性插值，位置为 (n-1)*q。失败请求保留在原始结果中，延迟分位数只统计成功项；存在失败时不视为完成。

## 已完成内容与结果

| 指标 | 共享前缀 | 分散前缀 |
|---|---:|---:|
| 成功请求 | 32/32 | 32/32 |
| 缓存命中率 | 96.9697% | 0% |
| Prefill token 总数 | 2048 | 67584 |
| 请求吞吐量（请求/s） | 48.3517 | 7.9441 |
| TTFT p50（ms） | 43.313 | 533.409 |
| TTFT p95（ms） | 55.494 | 793.492 |
| TPOT p50（ms） | 7.646 | 31.016 |
| TPOT p95（ms） | 8.608 | 53.203 |
| 端到端延迟 p50（ms） | 161.406 | 1009.126 |
| 端到端延迟 p95（ms） | 169.272 | 1020.663 |

每组输入共 67584 token、输出共 512 token；实际峰值并发为 8。
完成条件检查为 true；额外文件核对在 `results/target1/verification.json`。
主表的完整指标对应 `report.pdf` 第 2 页，与两组 `summary.json` 逐项一致。
表中的时间是客户端观测值，吞吐量来自一次固定配置测试，不是 GPU 峰值性能。

任务二流程图和源码说明在报告第 4、5 页；官方 v0.5.14 源码链接在 `src/target2/source-map.md`。
前缀匹配实际入口为 `Req.init_next_round_input → tree_cache.match_prefix`；
本次核对的两个管理文件中未找到题目列出的同名 `match_prefix_for_req` 函数。

## 作业感受与提交文件

作业感受第（2）问读取“作业感受.docx”的已保存文字，逐段原样加入报告。
第（3）问保留“我觉得像这样从零到一的工作并不难.docx”的全部原文，在开头补充本人指定原句：“我觉得包含对未知领域的研究，对已知领域的优化与应用”。
文字快照在 `src/report/reflections.json`；本次纳入时没有润色这两段回答。
此前会话中的代码讲解、技术表述检查、少量文字修改建议及题意解释，已在 AI 使用说明中按实际情况记录。
report.pdf 共 6 页，不超过 8 页；AI 使用说明单独保存。
提交前由本人检查全部内容，再打包为同名根目录的 HW2-姜佳岩.zip；排除 __pycache__ 等临时文件。

## 已核对的接口来源

- https://github.com/sgl-project/sglang/blob/49e384ce9d304648e9959666ecb8ce8cd98d0deb/python/sglang/srt/entrypoints/http_server.py
- https://github.com/sgl-project/sglang/blob/49e384ce9d304648e9959666ecb8ce8cd98d0deb/python/sglang/srt/managers/tokenizer_manager.py
- https://github.com/sgl-project/sglang/blob/49e384ce9d304648e9959666ecb8ce8cd98d0deb/python/sglang/srt/server_args.py

## 零基础源码阅读

`src/target2/零基础源码阅读讲义.md` 按少量 Python 写法、真实代码片段、逐句解释和实验例子组织。
源码固定提交为 `49e384ce9d304648e9959666ecb8ce8cd98d0deb`；实际行号及官方链接见 `src/target2/source-map.md`。
讲义是学习辅助材料；技术报告整理完成不代表本人已完成独立阅读和理解。
