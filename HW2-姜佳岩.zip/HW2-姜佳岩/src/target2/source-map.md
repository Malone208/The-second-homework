# SGLang 请求流程源码定位

来源为官方 `release/v0.5.14` 分支，核对时固定到提交 `49e384ce9d304648e9959666ecb8ce8cd98d0deb`。
行号直接按 GitHub 原始文件计算，与用户截图中的入口 576 行、发送 1325 行、入队 2265 行一致。
旧记录中的近似行号来自网页解析，已替换为下面的实际行号。

| 环节 | 文件（python/sglang/srt/ 下） | 定位 |
|---|---|---|
| 接收原生请求 | entrypoints/http_server.py | generate_request（769 行）；SSE 发送（778、797 行）。 |
| 管理请求 | managers/tokenizer_manager.py | TokenizerManager.generate_request（576 行）；input_ids 分支（803 行）。 |
| 转交调度器 | managers/tokenizer_manager.py | _send_one_request（1319 行）；发送对象（1325 行）。 |
| 接收与排队 | managers/scheduler.py | event_loop_normal（1505 行）；handle_generate_request（1998 行）；_add_request_to_queue（2258 行）。 |
| 选择 Prefill 请求 | managers/scheduler.py | get_new_batch_prefill（2702 行）；_get_new_batch_prefill_raw（2722 行）；前缀初始化调用（2847 行）。 |
| 初始化前缀状态 | managers/schedule_batch.py | Req.init_next_round_input（1123 行）；tree_cache.match_prefix 调用（1166 行）。 |
| Radix 树匹配 | mem_cache/radix_cache.py | RadixCache.match_prefix（358 行）。 |
| 预算与组批 | managers/schedule_policy.py、managers/schedule_batch.py | PrefillAdder（425 行）；add_one_req（858 行）；prepare_for_extend（2008 行）。 |
| 模型执行 | managers/tp_worker.py | TpModelWorker.forward_batch_generation（482 行）；model_runner.forward 调用（507 行）。 |
| 结果处理 | managers/scheduler_components/batch_result_processor.py | process_batch_result_prefill（178 行）；process_batch_result_decode（636 行）。 |
| 缓存维护入口 | mem_cache/common.py | maybe_cache_unfinished_req（113 行）；release_kv_cache（629 行）。 |
| 缓存登记 | mem_cache/radix_cache.py | cache_finished_req（438 行）；cache_unfinished_req（485 行）。 |
| 流式返回状态 | managers/tokenizer_manager.py | _wait_one_response（1425 行）；_handle_batch_output（1839 行）。 |

请求主线：HTTP → TokenizerManager → Scheduler / waiting_queue → 前缀匹配 → PrefillAdder / ScheduleBatch → Prefill / Decode → KV 维护和结果处理 → TokenizerManager → HTTP SSE。

阅读使用 event_loop_normal 作为参考；开启 overlap 时可走 event_loop_overlap，不把参考路径当作本机实际运行循环的证明。题目所列 match_prefix_for_req 在本次核对的两个管理文件中未找到同名函数，实际入口为 Req.init_next_round_input → tree_cache.match_prefix。

零基础阅读讲义：同目录 `零基础源码阅读讲义.md`；独立 PDF 位于工作目录 `output/pdf/任务二零基础源码阅读讲义.pdf`。

## 固定提交的官方源码

- [entrypoints/http_server.py](https://github.com/sgl-project/sglang/blob/49e384ce9d304648e9959666ecb8ce8cd98d0deb/python/sglang/srt/entrypoints/http_server.py)
- [managers/tokenizer_manager.py](https://github.com/sgl-project/sglang/blob/49e384ce9d304648e9959666ecb8ce8cd98d0deb/python/sglang/srt/managers/tokenizer_manager.py)
- [managers/scheduler.py](https://github.com/sgl-project/sglang/blob/49e384ce9d304648e9959666ecb8ce8cd98d0deb/python/sglang/srt/managers/scheduler.py)
- [managers/schedule_batch.py](https://github.com/sgl-project/sglang/blob/49e384ce9d304648e9959666ecb8ce8cd98d0deb/python/sglang/srt/managers/schedule_batch.py)
- [managers/schedule_policy.py](https://github.com/sgl-project/sglang/blob/49e384ce9d304648e9959666ecb8ce8cd98d0deb/python/sglang/srt/managers/schedule_policy.py)
- [managers/tp_worker.py](https://github.com/sgl-project/sglang/blob/49e384ce9d304648e9959666ecb8ce8cd98d0deb/python/sglang/srt/managers/tp_worker.py)
- [mem_cache/radix_cache.py](https://github.com/sgl-project/sglang/blob/49e384ce9d304648e9959666ecb8ce8cd98d0deb/python/sglang/srt/mem_cache/radix_cache.py)
- [mem_cache/common.py](https://github.com/sgl-project/sglang/blob/49e384ce9d304648e9959666ecb8ce8cd98d0deb/python/sglang/srt/mem_cache/common.py)
- [managers/scheduler_components/batch_result_processor.py](https://github.com/sgl-project/sglang/blob/49e384ce9d304648e9959666ecb8ce8cd98d0deb/python/sglang/srt/managers/scheduler_components/batch_result_processor.py)
