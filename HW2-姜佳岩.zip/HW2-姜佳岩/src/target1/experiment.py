"""HW2 native /generate prefix-cache experiment. Results require a live server."""
from __future__ import annotations

import argparse
import hashlib
import http.client
import importlib.metadata
import json
import math
from pathlib import Path
import random
import re
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "src" / "target1" / "workloads"
PARAMS = {"temperature": 0, "max_new_tokens": 16,
          "ignore_eos": True, "sampling_seed": 2026}
GROUPS = ("shared_prefix", "dispersed_prefix")


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def construct(pool):
    if len(set(pool)) < 256:
        raise ValueError("Need at least 256 distinct non-special vocabulary IDs")
    rng = random.Random(2026)
    prefix = [pool[0]] + rng.choices(pool[128:], k=2047)
    suffixes = [[pool[64+i]] + rng.choices(pool[128:], k=63) for i in range(32)]
    workloads = {
        "shared_prefix": [prefix + s for s in suffixes],
        "dispersed_prefix": [[pool[i+1]] + prefix[1:] + s for i, s in enumerate(suffixes)],
    }
    warmup = prefix + [pool[96]] + rng.choices(pool[128:], k=63)
    for group, rows in workloads.items():
        assert len(rows) == 32 and all(len(row) == 2112 for row in rows)
    assert len({r[0] for r in workloads["dispersed_prefix"]}) == 32
    assert all(r[:2048] == prefix for r in workloads["shared_prefix"])
    assert len({r[2048] for r in workloads["shared_prefix"]}) == 32
    assert all(a[1:] == b[1:] for a, b in zip(*workloads.values()))
    return workloads, warmup


def prepare(tokenizer_path):
    from transformers import AutoTokenizer
    if not tokenizer_path:
        base = Path.home() / ".cache/modelscope/models"
        matches = sorted(base.glob("**/tokenizer.json"))
        matches = [p for p in matches if "Qwen3-0.6B" in str(p)]
        if len(matches) != 1:
            raise ValueError("Cannot uniquely locate Qwen3-0.6B tokenizer; pass --tokenizer PATH")
        tokenizer_path = str(matches[0].parent)
    tok = AutoTokenizer.from_pretrained(str(Path(tokenizer_path).expanduser()), local_files_only=True)
    special = set(tok.all_special_ids)
    pool = sorted({i for text, i in tok.get_vocab().items()
                   if i not in special and re.fullmatch(r"[A-Za-z]{1,12}", text)})
    workloads, warmup = construct(pool)
    for group, rows in workloads.items():
        p = DATA / (group + ".jsonl")
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("w", encoding="utf-8") as f:
            for i, ids in enumerate(rows):
                f.write(json.dumps({"index": i, "input_ids": ids}) + "\n")
    save(DATA / "warmup.json", {"input_ids": warmup})
    save(DATA / "manifest.json", {
        "tokenizer_path": tokenizer_path, "seed": 2026, "requests_per_group": 32,
        "prefix_tokens": 2048, "suffix_tokens": 64, "input_tokens": 2112,
        "concurrency": 8, "sampling_params": PARAMS,
        "design": "Paired inputs differ only in first token; suffix starts are unique.",
        "sha256": {g: hashlib.sha256((DATA/(g+'.jsonl')).read_bytes()).hexdigest() for g in GROUPS},
    })
    print("已生成两组负载：每组 32 条，每条 2112 token；共享前缀 2048 token。")
    print("负载目录：", DATA)


def sse_events(lines):
    data = []
    for raw in lines:
        line = raw.decode("utf-8").rstrip("\r\n")
        if not line:
            if data:
                yield "\n".join(data)
                data = []
        elif line.startswith("data:"):
            data.append(line[5:].lstrip(" "))
    if data:
        yield "\n".join(data)


class OrderedDispatch:
    def __init__(self):
        self.condition = threading.Condition()
        self.next_index = 0

    def send(self, index, operation):
        with self.condition:
            self.condition.wait_for(lambda: self.next_index == index)
            try:
                return operation()
            finally:
                self.next_index += 1
                self.condition.notify_all()


class Client:
    def __init__(self, url):
        parts = urlsplit(url)
        if parts.scheme != "http" or parts.path not in ("", "/"):
            raise ValueError("Use an http://host:port server URL without a path")
        self.host, self.port = parts.hostname, parts.port or 80

    def connection(self):
        return http.client.HTTPConnection(self.host, self.port, timeout=180)

    def request(self, method, path):
        conn = self.connection()
        try:
            conn.request(method, path, headers={"Content-Length": "0"})
            response = conn.getresponse()
            body = response.read().decode("utf-8")
            if response.status != 200:
                raise RuntimeError(f"{path}: HTTP {response.status}: {body}")
            return {"status": response.status, "body": body}
        finally:
            conn.close()

    def flush(self):
        result = self.request("POST", "/flush_cache?timeout=30")
        if "Cache flushed" not in result["body"]:
            raise RuntimeError("HTTP 200 but cache flush success was not confirmed")
        return result

    def generate(self, ids, index=0, gate=None):
        payload = json.dumps({"input_ids": ids, "stream": True,
                              "sampling_params": PARAMS}).encode("utf-8")
        conn = self.connection()
        result = {"index": index, "status": None, "success": False,
                  "events": [], "sampling_params": PARAMS}
        first = last = None
        first_count = None
        done = False
        latest = {}
        start = None
        def send():
            nonlocal start
            start = time.perf_counter()
            conn.request("POST", "/generate", payload,
                         {"Content-Type": "application/json", "Accept": "text/event-stream"})
        try:
            gate.send(index, send) if gate else send()
            response = conn.getresponse()
            result["status"] = response.status
            if response.status != 200:
                raise RuntimeError(response.read().decode("utf-8"))
            if "text/event-stream" not in response.getheader("Content-Type", ""):
                raise RuntimeError("Response is not an SSE stream")
            previous_count = 0
            for event in sse_events(response):
                now = time.perf_counter()
                if event == "[DONE]":
                    done = True
                    break
                obj = json.loads(event)
                result["events"].append({"elapsed_s": now-start, "response": obj})
                if "error" in obj:
                    raise RuntimeError(json.dumps(obj["error"], ensure_ascii=False))
                latest = obj.get("meta_info", {})
                count = int(latest.get("completion_tokens", 0))
                if count < previous_count:
                    raise RuntimeError("Completion token count decreased")
                if count > previous_count:
                    if first is None:
                        first, first_count = now, count
                    last = now
                    previous_count = count
            for key in ("prompt_tokens", "completion_tokens", "cached_tokens"):
                if key not in latest:
                    raise RuntimeError("Missing meta_info field: " + key)
            p, n, c = (int(latest[k]) for k in ("prompt_tokens", "completion_tokens", "cached_tokens"))
            if not done or not latest.get("finish_reason"):
                raise RuntimeError("Stream ended without DONE or finish_reason")
            if p != len(ids) or n != 16 or not (0 <= c <= p):
                raise RuntimeError(f"Unexpected lengths/cache: prompt={p}, output={n}, cached={c}")
            if first is None:
                raise RuntimeError("No output token observed")
            result.update(success=True, prompt_tokens=p, completion_tokens=n,
                          cached_tokens=c, prefill_tokens=p-c,
                          ttft_s=first-start, tpot_s=(last-first)/(n-1),
                          first_observed_completion_tokens=first_count,
                          single_token_first_event=(first_count == 1),
                          final_meta_info=latest)
        except Exception as exc:
            result["error"] = f"{type(exc).__name__}: {exc}"
        finally:
            end = time.perf_counter()
            result.update(start_monotonic_s=start, end_monotonic_s=end,
                          latency_s=end-start if start is not None else None)
            conn.close()
        return result


def percentile(values, q):
    values = sorted(values)
    pos = (len(values)-1)*q
    lo, hi = math.floor(pos), math.ceil(pos)
    return values[lo] + (values[hi]-values[lo])*(pos-lo)


def summarize(rows, group):
    good = [r for r in rows if r["success"]]
    duration = max(r["end_monotonic_s"] for r in rows) - min(r["start_monotonic_s"] for r in rows if r["start_monotonic_s"] is not None)
    s = {"group": group, "requests": len(rows), "successful_requests": len(good),
         "success_rate": len(good)/len(rows), "measurement_duration_s": duration,
         "requests_per_s": len(good)/duration,
         "output_tokens_per_s": sum(r["completion_tokens"] for r in good)/duration,
         "prompt_tokens": sum(r["prompt_tokens"] for r in good),
         "completion_tokens": sum(r["completion_tokens"] for r in good),
         "cached_tokens": sum(r["cached_tokens"] for r in good),
         "prefill_tokens": sum(r["prefill_tokens"] for r in good),
         "single_token_first_event_all": all(r["single_token_first_event"] for r in good) if good else False}
    s["cache_hit_rate"] = s["cached_tokens"]/s["prompt_tokens"] if s["prompt_tokens"] else None
    for metric in ("ttft_s", "tpot_s", "latency_s"):
        values = [r[metric] for r in good]
        for q in (0.5, 0.95):
            s[f"{metric}_p{int(q*100)}"] = percentile(values, q) if values else None
    return s


def load_workloads():
    rows = {g: [json.loads(line) for line in (DATA/(g+'.jsonl')).read_text(encoding="utf-8").splitlines()] for g in GROUPS}
    for group, items in rows.items():
        if len(items) != 32 or [r["index"] for r in items] != list(range(32)):
            raise ValueError("Wrong request count/order: " + group)
        if any(len(r["input_ids"]) != 2112 for r in items):
            raise ValueError("Input length must be 2112: " + group)
    manifest = json.loads((DATA/"manifest.json").read_text(encoding="utf-8"))
    for g in GROUPS:
        if hashlib.sha256((DATA/(g+'.jsonl')).read_bytes()).hexdigest() != manifest["sha256"][g]:
            raise ValueError("Workload changed after preparation: " + g)
    return rows


def probe(client):
    ids = load_workloads()["shared_prefix"][0]["input_ids"][:64]
    result = client.generate(ids)
    save(ROOT/"results/target1/probe.json", result)
    for key in ("status", "success", "prompt_tokens", "completion_tokens", "cached_tokens", "first_observed_completion_tokens", "ttft_s", "tpot_s", "error"):
        if key in result:
            print(key + ":", result[key])
    print("流式事件中的累计输出 token 数：", [e["response"].get("meta_info", {}).get("completion_tokens") for e in result["events"]])
    if not result["success"] or not result["single_token_first_event"]:
        raise RuntimeError("Probe failed or first stream event contains multiple tokens; inspect probe.json before measuring")


def run(client, run_name):
    if not re.fullmatch(r"run-[1-9][0-9]*", run_name):
        raise ValueError("Use run-1, run-2, ...")
    versions = {name: importlib.metadata.version(name) for name in ("sglang", "ray", "torch")}
    if versions["sglang"] != "0.5.14" or versions["ray"] != "2.56.0":
        raise ValueError("Required versions not found: " + str(versions))
    workloads = load_workloads()
    dirs = {g: ROOT/"results/target1"/g/run_name for g in GROUPS}
    if any(p.exists() and any(p.iterdir()) for p in dirs.values()):
        raise ValueError("Results exist; choose a new --run-name to avoid overwriting")
    warm = client.generate(workloads["shared_prefix"][0]["input_ids"][:64])
    if not warm["success"]:
        raise RuntimeError("Service warmup failed: " + str(warm.get("error")))
    summaries = []
    for group in GROUPS:
        out = dirs[group]
        prep = {"flush": client.flush(), "versions": versions, "service_warmup": warm if group == GROUPS[0] else None}
        if group == "shared_prefix":
            ids = json.loads((DATA/"warmup.json").read_text(encoding="utf-8"))["input_ids"]
            prep["prefix_warmup"] = client.generate(ids)
            if not prep["prefix_warmup"]["success"]:
                raise RuntimeError("Prefix warmup failed")
        save(out/"preparation.json", prep)
        gate, results = OrderedDispatch(), []
        with ThreadPoolExecutor(max_workers=8) as executor:
            futures = [executor.submit(client.generate, r["input_ids"], r["index"], gate) for r in workloads[group]]
            for future in as_completed(futures):
                row = future.result()
                save(out/"streams"/f"request-{row['index']:02d}.json", row)
                results.append(row)
                print(group, row["index"], "OK" if row["success"] else row.get("error"),
                      "cached=", row.get("cached_tokens"), "latency=", round(row["latency_s"], 4) if row["latency_s"] is not None else None, flush=True)
        results.sort(key=lambda r: r["index"])
        with (out/"requests.jsonl").open("w", encoding="utf-8") as f:
            for row in results:
                f.write(json.dumps({k:v for k,v in row.items() if k != "events"}, ensure_ascii=False) + "\n")
        summary = summarize(results, group)
        save(out/"summary.json", summary)
        summaries.append(summary)
    passed = all(s["successful_requests"] == 32 and s["prompt_tokens"] == 32*2112 and s["completion_tokens"] == 32*16 and s["single_token_first_event_all"] for s in summaries)
    passed = passed and summaries[0]["cache_hit_rate"] > summaries[1]["cache_hit_rate"] and summaries[0]["prefill_tokens"] < summaries[1]["prefill_tokens"]
    save(ROOT/"results/target1"/(run_name+"-comparison.json"), {"groups": summaries, "assignment_checks_passed": passed})
    print(json.dumps({"groups": summaries, "assignment_checks_passed": passed}, ensure_ascii=False, indent=2))
    if not passed:
        raise RuntimeError("Some assignment/stream-resolution checks failed; preserve results and inspect them")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("prepare", "probe", "run"))
    parser.add_argument("--tokenizer")
    parser.add_argument("--server", default="http://127.0.0.1:30000")
    parser.add_argument("--run-name", default="run-1")
    args = parser.parse_args()
    if args.action == "prepare":
        prepare(args.tokenizer)
    elif args.action == "probe":
        probe(Client(args.server))
    else:
        run(Client(args.server), args.run_name)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("停止：", exc, file=sys.stderr)
        sys.exit(1)
